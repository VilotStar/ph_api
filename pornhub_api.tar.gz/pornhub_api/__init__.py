from pornhub_api.api import PornhubApi

__all__ = ("PornhubApi",)
